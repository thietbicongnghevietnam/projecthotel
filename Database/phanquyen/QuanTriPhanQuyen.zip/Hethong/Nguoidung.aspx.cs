using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using WebApplication1.App_Code;

namespace WebApplication1.Hethong
{
    public partial class Nguoidung : BasePage
    {
        protected override string RequiredPermission
        {
            get { return "SYS_NGUOIDUNG.VIEW"; }
        }

        private int CurrentUserId
        {
            get { return Convert.ToInt32(Session["userid"]); }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindRoles();
                BindUsers();
                ResetForm();
            }
        }

        private void BindRoles()
        {
            DataTable dt = DataConn.StoreFillDS("pro_role_list", CommandType.StoredProcedure);
            cblRoles.DataSource = dt;
            cblRoles.DataTextField = "ROLE_NAME";
            cblRoles.DataValueField = "ROLE_ID";
            cblRoles.DataBind();
        }

        private void BindUsers()
        {
            gvUsers.DataSource = DataConn.StoreFillDS("pro_user_list", CommandType.StoredProcedure);
            gvUsers.DataBind();
        }

        private void ResetForm()
        {
            hfUserId.Value = "0";
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtPassword.Attributes["placeholder"] = "Bắt buộc với người dùng mới";
            txtFullName.Text = "";
            txtEmail.Text = "";
            chkActive.Checked = true;
            chkActive.Enabled = true;
            foreach (ListItem li in cblRoles.Items) li.Selected = false;

            lblFormTitle.Text = "Thêm người dùng";
            pnlForm.Visible = Auth.Has("SYS_NGUOIDUNG.ADD") || Auth.Has("SYS_NGUOIDUNG.EDIT");
            btnSave.Visible = Auth.Has("SYS_NGUOIDUNG.ADD");
            btnNew.Visible = Auth.Has("SYS_NGUOIDUNG.ADD");
        }

        private void LoadUser(int id)
        {
            DataTable dt = DataConn.StoreFillDS("pro_user_get", CommandType.StoredProcedure, id);
            if (dt.Rows.Count == 0) { ShowMsg("Không tìm thấy người dùng.", false); return; }

            DataRow r = dt.Rows[0];
            hfUserId.Value = id.ToString();
            txtUserName.Text = Convert.ToString(r["U_NAME"]);
            txtPassword.Text = "";
            txtPassword.Attributes["placeholder"] = "Để trống nếu không đổi mật khẩu";
            txtFullName.Text = Convert.ToString(r["U_FULLNAME"]);
            txtEmail.Text = Convert.ToString(r["U_EMAIL"]);
            chkActive.Checked = Convert.ToString(r["U_ACTIVE"]) == "Y";
            chkActive.Enabled = id != CurrentUserId;          // không tự khóa chính mình

            string[] roleIds = Convert.ToString(r["ROLE_IDS"]).Split(',');
            foreach (ListItem li in cblRoles.Items) li.Selected = roleIds.Contains(li.Value);

            lblFormTitle.Text = "Sửa người dùng: " + HttpUtility.HtmlEncode(txtUserName.Text);
            pnlForm.Visible = true;
            btnSave.Visible = Auth.Has("SYS_NGUOIDUNG.EDIT");
        }

        protected void gvUsers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;

            int id = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "U_ID"));
            bool canEdit = Auth.Has("SYS_NGUOIDUNG.EDIT");

            e.Row.FindControl("btnEdit").Visible = canEdit;
            e.Row.FindControl("btnToggle").Visible = canEdit && id != CurrentUserId;
        }

        protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "EditUser" && e.CommandName != "ToggleUser") return;

            Auth.Require("SYS_NGUOIDUNG.EDIT");
            int id = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "EditUser")
            {
                LoadUser(id);
                return;
            }

            // ToggleUser
            if (id == CurrentUserId)
            {
                ShowMsg("Không thể tự khóa tài khoản đang đăng nhập.", false);
                return;
            }

            DataTable dt = DataConn.StoreFillDS("pro_user_toggle_active", CommandType.StoredProcedure, id);
            if (dt.Rows[0]["RESULT"].ToString() == "NOADMIN")
            {
                ShowMsg("Hệ thống phải còn ít nhất 1 tài khoản ADMIN đang hoạt động.", false);
                return;
            }

            BindUsers();
            if (hfUserId.Value == id.ToString()) LoadUser(id);
            ShowMsg(dt.Rows[0]["U_ACTIVE"].ToString() == "Y" ? "Đã mở khóa tài khoản." : "Đã khóa tài khoản.", true);
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            ResetForm();
            txtUserName.Focus();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(hfUserId.Value);
            Auth.Require(id == 0 ? "SYS_NGUOIDUNG.ADD" : "SYS_NGUOIDUNG.EDIT");

            string userName = txtUserName.Text.Trim();
            string password = txtPassword.Text;                  // lưu nguyên văn theo yêu cầu
            string roleIds = string.Join(",", cblRoles.Items.Cast<ListItem>()
                                                          .Where(li => li.Selected)
                                                          .Select(li => li.Value));
            bool active = chkActive.Checked;
            if (id == CurrentUserId) active = true;              // không tự khóa mình

            if (userName.Length == 0) { ShowMsg("Vui lòng nhập tên đăng nhập.", false); return; }
            if (id == 0 && password.Length == 0) { ShowMsg("Vui lòng nhập mật khẩu cho người dùng mới.", false); return; }
            if (roleIds.Length == 0) { ShowMsg("Vui lòng chọn ít nhất 1 nhóm quyền.", false); return; }

            DataTable dt = DataConn.StoreFillDS("pro_user_save", CommandType.StoredProcedure,
                                                id, userName, password,
                                                txtFullName.Text.Trim(), txtEmail.Text.Trim(),
                                                active ? "Y" : "N", roleIds);
            string result = dt.Rows[0]["RESULT"].ToString();

            if (result == "DUP") { ShowMsg("Tên đăng nhập '" + userName + "' đã tồn tại.", false); return; }
            if (result == "NOADMIN") { ShowMsg("Hệ thống phải còn ít nhất 1 tài khoản ADMIN đang hoạt động.", false); return; }

            int savedId = Convert.ToInt32(dt.Rows[0]["U_ID"]);
            if (savedId == CurrentUserId) Auth.LoadPermissions(savedId);   // sửa chính mình thì nạp lại quyền

            BindUsers();
            LoadUser(savedId);
            ShowMsg(id == 0 ? "Đã thêm người dùng." : "Đã lưu thay đổi.", true);
        }

        private void ShowMsg(string text, bool ok)
        {
            pnlMsg.Visible = true;
            pnlMsg.CssClass = ok ? "alert alert-success" : "alert alert-danger";
            litMsg.Text = HttpUtility.HtmlEncode(text);
        }
    }
}
